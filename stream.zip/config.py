

# config.py - Updated for PostgreSQL

BOT_TOKEN = "8602633218:AAHDDlEAMcnamsNDte0hU_CxF1dXmkLsAfc"
ADMIN_IDS = [8015937475]
API_ID = 21538384
API_HASH = "9b8e9b10a5c34b67054aceca02bf423e"

# PostgreSQL (MIGRATED FROM MONGODB)
USE_POSTGRES = True
POSTGRES_HOST = 'localhost'
POSTGRES_PORT = 5432
POSTGRES_DB = 'zayrosmm'
POSTGRES_USER = 'zayrosmm'
POSTGRES_PASSWORD = 'zayrosmm'

# Redis Caching (recommended)
USE_REDIS = True
REDIS_HOST = 'localhost'
REDIS_PORT = 6379
REDIS_DB = 0
REDIS_PASSWORD = None

# Legacy MongoDB (deprecated, do not use)
USE_MONGODB = False